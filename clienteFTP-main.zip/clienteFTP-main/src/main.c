#include "ftp_client.h"
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <sys/wait.h>

void sigchld_handler(int sig) {
    int status;
    while (waitpid(-1, &status, WNOHANG) > 0)
        printf("Proceso hijo finalizado\n");
}

int main(int argc, char *argv[]) {
    if (argc != 3) {
        fprintf(stderr, "Uso: %s <servidor> <puerto>\n", argv[0]);
        exit(1);
    }
    struct sigaction sa;
    sa.sa_handler = sigchld_handler;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_RESTART | SA_NOCLDSTOP;
    sigaction(SIGCHLD, &sa, NULL);

    int sockfd = ftp_connect(argv[1], argv[2]);

    char user[64], pass[64];
    printf("Nombre de usuario: ");
    fgets(user, sizeof(user), stdin);
    user[strcspn(user, "\n")] = 0;
    printf("Contraseña: ");
    fgets(pass, sizeof(pass), stdin);
    pass[strcspn(pass, "\n")] = 0;

    if (ftp_login(sockfd, user, pass) < 0) {
        fprintf(stderr, "Error de autenticación\n");
        close(sockfd);
        exit(1);
    }

    char cmd[MAX_COMMAND], filename[MAX_FILENAME];
    while (1) {
        printf("ftp> ");
        if (!fgets(cmd, MAX_COMMAND, stdin)) break;
        cmd[strcspn(cmd, "\n")] = 0;
        if (strlen(cmd) == 0) continue;

        char *args = strchr(cmd, ' ');
        if (args) *args++ = 0;
        else args = "";

        if (strcasecmp(cmd, "QUIT") == 0) break;
        else if (strcasecmp(cmd, "STOR") == 0) {
            pid_t pid = fork();
            if (pid == 0) {
                ftp_stor(sockfd, args);
                exit(0);
            }
        }
        else if (strcasecmp(cmd, "RETR") == 0) {
            pid_t pid = fork();
            if (pid == 0) {
                ftp_retr(sockfd, args);
                exit(0);
            }
        }
        else {
            printf("Comando no soportado: %s\n", cmd);
        }
    }
    close(sockfd);
    printf("Bye\n");
    return 0;
}
