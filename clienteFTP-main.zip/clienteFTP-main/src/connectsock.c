#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
extern void errexit(const char *, ...);

int connectsock(const char *host, const char *service, const char *transport) {
    struct addrinfo hints, *res;
    int sockfd, type;

    memset(&hints, 0, sizeof(hints));
    hints.ai_family = AF_INET;
    if (strcmp(transport, "tcp") == 0)
        hints.ai_socktype = SOCK_STREAM;
    else if (strcmp(transport, "udp") == 0)
        hints.ai_socktype = SOCK_DGRAM;
    else
        errexit("Invalid transport: %s", transport);

    if (getaddrinfo(host, service, &hints, &res) != 0)
        errexit("getaddrinfo failed");

    sockfd = socket(res->ai_family, res->ai_socktype, res->ai_protocol);
    if (sockfd < 0)
        errexit("socket creation failed");

    if (connect(sockfd, res->ai_addr, res->ai_addrlen) < 0)
        errexit("connect failed");

    freeaddrinfo(res);
    return sockfd;
}
