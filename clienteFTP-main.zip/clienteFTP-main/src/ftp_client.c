#include "ftp_client.h"
#include <stdio.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/wait.h>

extern void errexit(const char *format, ...);
extern int connectsock(const char *host, const char *service, const char *transport);

// Conectar al servidor FTP
int ftp_connect(const char *host, const char *port) {
    int sockfd = connectTCP(host, port);
    char response[MAX_RESPONSE];
    if (ftp_read_response(sockfd, response, MAX_RESPONSE) != 220) {
        close(sockfd);
        errexit("No se recibió el mensaje de bienvenida 220");
    }
    printf("Conectado: %s", response);
    return sockfd;
}

// Leer respuesta del servidor
int ftp_read_response(int sockfd, char *buffer, int bufsize) {
    int n = read(sockfd, buffer, bufsize - 1);
    if (n <= 0) return -1;
    buffer[n] = '\0';
    int code = (buffer[0] - '0') * 100 + (buffer[1] - '0') * 10 + (buffer[2] - '0');
    return code;
}

// Enviar comando
void ftp_send_command(int sockfd, const char *cmd) {
    char buffer[MAX_COMMAND];
    snprintf(buffer, MAX_COMMAND, "%s\r\n", cmd);
    write(sockfd, buffer, strlen(buffer));
}

// Autenticación
int ftp_login(int sockfd, const char *user, const char *pass) {
    char cmd[MAX_COMMAND], response[MAX_RESPONSE];
    // USER
    snprintf(cmd, MAX_COMMAND, "USER %s", user);
    ftp_send_command(sockfd, cmd);
    int code = ftp_read_response(sockfd, response, MAX_RESPONSE);
    if (code != 331) return -1;
    // PASS
    snprintf(cmd, MAX_COMMAND, "PASS %s", pass);
    ftp_send_command(sockfd, cmd);
    code = ftp_read_response(sockfd, response, MAX_RESPONSE);
    if (code != 230) return -1;
    printf("Autenticación exitosa\n");
    return 0;
}

// Modo PASV
int ftp_pasv_connect(int control_sock) {
    char response[MAX_RESPONSE];
    
    // Enviar comando PASV
    ftp_send_command(control_sock, "PASV");
    
    // Leer respuesta 227
    int code = ftp_read_response(control_sock, response, MAX_RESPONSE);
    printf("PASV response: %s", response);
    
    if (code != 227) {
        fprintf(stderr, "Error: PASV failed with code %d\n", code);
        return -1;
    }
    
    // Parsear respuesta: 227 Entering Passive Mode (h1,h2,h3,h4,p1,p2)
    int h1, h2, h3, h4, p1, p2;
    char *start = strchr(response, '(');
    
    if (!start) {
        fprintf(stderr, "Error: No se encontró '(' en respuesta PASV\n");
        return -1;
    }
    
    if (sscanf(start, "(%d,%d,%d,%d,%d,%d)", &h1, &h2, &h3, &h4, &p1, &p2) != 6) {
        fprintf(stderr, "Error: No se pudieron parsear los 6 números de PASV\n");
        return -1;
    }
    
    // Construir dirección IP
    char ip[16];
    snprintf(ip, sizeof(ip), "%d.%d.%d.%d", h1, h2, h3, h4);
    
    // Calcular puerto: (p1 * 256) + p2
    int port = (p1 * 256) + p2;
    
    printf("Conectando a puerto de datos: %s:%d\n", ip, port);
    
    // Conectar al servidor en el puerto de datos
    char port_str[10];
    snprintf(port_str, sizeof(port_str), "%d", port);
    
    int data_sock = connectTCP(ip, port_str);
    
    if (data_sock < 0) {
        fprintf(stderr, "Error: No se pudo conectar a %s:%d\n", ip, port);
        return -1;
    }
    
    return data_sock;
}

// Transferencia RETR (modo PASV)
void ftp_retr(int sockfd, const char *filename) {
    char cmd[MAX_COMMAND], response[MAX_RESPONSE];
    
    // Establecer conexión de datos PASV
    int data_sock = ftp_pasv_connect(sockfd);
    if (data_sock < 0) {
        fprintf(stderr, "Error: No se pudo establecer conexión de datos PASV\n");
        exit(1);
    }
    
    // Enviar comando RETR
    snprintf(cmd, MAX_COMMAND, "RETR %s", filename);
    ftp_send_command(sockfd, cmd);
    
    // Leer respuesta 150
    int code = ftp_read_response(sockfd, response, MAX_RESPONSE);
    printf("RETR response: %s", response);
    
    if (code != 150) {
        fprintf(stderr, "Error: RETR falló con código %d\n", code);
        close(data_sock);
        exit(1);
    }
    
    // Abrir archivo local para escritura
    FILE *fp = fopen(filename, "wb");
    if (!fp) {
        perror("Error al abrir archivo local");
        close(data_sock);
        exit(1);
    }
    
    // Recibir datos y escribir al archivo
    char buffer[8192];
    ssize_t bytes;
    size_t total = 0;
    
    while ((bytes = read(data_sock, buffer, sizeof(buffer))) > 0) {
        fwrite(buffer, 1, bytes, fp);
        total += bytes;
    }
    
    printf("Recibidos %zu bytes\n", total);
    
    fclose(fp);
    close(data_sock);
    
    // Leer respuesta 226 (Transfer complete)
    code = ftp_read_response(sockfd, response, MAX_RESPONSE);
    printf("Transfer complete: %s", response);
    
    exit(0);
}

// Transferencia STOR (modo PORT)
void ftp_stor(int sockfd, const char *filename) {
    char cmd[MAX_COMMAND], response[MAX_RESPONSE];
    struct sockaddr_in addr;
    socklen_t len = sizeof(addr);
    getsockname(sockfd, (struct sockaddr *)&addr, &len);
    unsigned char *ip = (unsigned char *)&addr.sin_addr.s_addr;
    int data_server_sock = socket(AF_INET, SOCK_STREAM, 0);
    struct sockaddr_in local_addr;
    memset(&local_addr, 0, sizeof(local_addr));
    local_addr.sin_family = AF_INET;
    local_addr.sin_addr.s_addr = INADDR_ANY;
    local_addr.sin_port = 0;
    if (bind(data_server_sock, (struct sockaddr *)&local_addr, sizeof(local_addr)) < 0) {
        perror("bind");
        exit(1);
    }
    if (listen(data_server_sock, 1) < 0) {
        perror("listen");
        exit(1);
    }
    int data_server_port = ntohs(local_addr.sin_port);
    int p1 = data_server_port / 256;
    int p2 = data_server_port % 256;
    snprintf(cmd, MAX_COMMAND, "PORT %d,%d,%d,%d,%d,%d", ip[0], ip[1], ip[2], ip[3], p1, p2);
    ftp_send_command(sockfd, cmd);
    ftp_read_response(sockfd, response, MAX_RESPONSE);
    snprintf(cmd, MAX_COMMAND, "STOR %s", filename);
    ftp_send_command(sockfd, cmd);
    ftp_read_response(sockfd, response, MAX_RESPONSE);
    struct sockaddr_in client_addr;
    int data_sock = accept(data_server_sock, (struct sockaddr *)&client_addr, &len);
    close(data_server_sock);
    if (data_sock < 0) {
        perror("accept");
        exit(1);
    }
    FILE *fp = fopen(filename, "rb");
    if (!fp) {
        perror("fopen");
        exit(1);
    }
    char buffer[MAX_RESPONSE];
    size_t bytes;
    while ((bytes = fread(buffer, 1, MAX_RESPONSE, fp)) > 0) {
        write(data_sock, buffer, bytes);
    }
    fclose(fp);
    close(data_sock);
    ftp_read_response(sockfd, response, MAX_RESPONSE);
    printf("Subida completada: %s\n", filename);
    exit(0);
}
