#ifndef FTP_CLIENT_H
#define FTP_CLIENT_H
#include "ftp_defs.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/wait.h>
#include <netinet/in.h>
#include <arpa/inet.h>
extern int ftp_connect(const char *host, const char *port);
extern int ftp_login(int sockfd, const char *user, const char *pass);
extern int ftp_read_response(int sockfd, char *buffer, int bufsize);
extern void ftp_send_command(int sockfd, const char *cmd);
extern void ftp_retr(int sockfd, const char *filename);
extern void ftp_stor(int sockfd, const char *filename);
extern int ftp_pasv_connect(int sockfd);
#endif
