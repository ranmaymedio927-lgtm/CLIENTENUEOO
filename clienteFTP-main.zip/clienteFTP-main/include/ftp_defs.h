#ifndef FTP_DEFS_H
#define FTP_DEFS_H
#define MAX_COMMAND 256
#define MAX_RESPONSE 1024
#define MAX_FILENAME 256
#endif
